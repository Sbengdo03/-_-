# IF_Team16_융벤져스

# cmd
# pip install pandas
# pip install xlrd
# pip install openpyxl
# pip install numpy

# 모듈 불러오기
from tkinter import *
import tkinter.ttk as ttk
import pandas as pd
from numpy import empty
import webbrowser

# 엑셀 파일 불러오기
df_qst = pd.read_excel(io="excel/IF_Team16_qstList&ansList.xlsx",
                       sheet_name="qstList")  # 질문 리스트
df_ans = pd.read_excel(io="excel/IF_Team16_qstList&ansList.xlsx",
                       sheet_name="ansList")  # 답변 리스트
df_setD = pd.read_excel(io="excel/IF_Team16_setData.xlsx",
                        sheet_name="setData", engine='openpyxl')  # 표본 데이터 리스트

# 답변 항목에서 문항별 선택지 개수 차이로 인한 문제 : 'nan' 발생 문제 해결용
df_ans = df_ans.fillna("null")

# 변수 정의
cnt = 0  # 문제 번호 (0~10 : 총 질문 11개)
user_info = []  # 사용자 입력 정보 리스트
a = 1  # nextWdw 함수에서 사용
max_num = 0  # 표본과의 비교 점수를 모두 담은 리스트에서 가장 높은 점수의 인덱스 값
fnt = "DX경필고딕B"  # 사용 폰트

# 메인
s = Tk()
s.title("IF_Team16_융벤져스_돔메를 찾아서")
# 창 크기 및 위치 설정 / 스크린의 중앙에 프로그램이 실행되게 하기 위함
w = 500
h = 770
sw = s.winfo_screenwidth()
sh = s.winfo_screenheight()
x = (sw-w)/2
y = (sh-h)/2 - 35
s.geometry('%dx%d+%d+%d' % (w, h, x, y))
s.resizable(width=False, height=False)


# [기숙사 정보보기] 버튼
def Eurl():
    webbrowser.open(
        "https://dorm.skku.edu/dorm_seoul/lifeguide/e_house_living.jsp")

def Gurl():
    webbrowser.open(
        "https://dorm.skku.edu/dorm_seoul/lifeguide/g_house_living.jsp")

def Kurl():
    webbrowser.open(
        "https://dorm.skku.edu/dorm_seoul/lifeguide/k_house_living.jsp")

def Edorm():
    window = Toplevel(s)
    window.title("E하우스 정보 보기")
    window.configure(bg='white')
    # 창 크기 및 위치 설정
    w = 600
    h = 470
    sw = window.winfo_screenwidth()
    sh = window.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2 - 50
    window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    window.resizable(width=False, height=False)
    photo = PhotoImage(file="img/eHouse.png")
    eh = Label(window, image=photo)
    eh.pack()
    Label(window, text="E하우스", bg='white', font=fnt).pack()
    ubtn = Button(window, text="정보 더보기", bg="white",
                  command=Eurl, font=fnt, width=30)
    ubtn.pack()
    window.mainloop()


def Gdorm():
    window = Toplevel(s)
    window.title("G하우스 정보 보기")
    window.configure(bg='white')
    # 창 크기 및 위치 설정
    w = 600
    h = 470
    sw = window.winfo_screenwidth()
    sh = window.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2 - 50
    window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    window.resizable(width=False, height=False)
    photo = PhotoImage(file="img/gHouse.png")
    eh = Label(window, image=photo)
    eh.pack()
    Label(window, text="G하우스", bg='white', font=fnt).pack()
    ubtn = Button(window, text="정보 더보기", bg="white",
                  command=Gurl, font=fnt, width=30)
    ubtn.pack()
    window.mainloop()


def Kdorm():
    window = Toplevel(s)
    window.title("K하우스 정보 보기")
    window.configure(bg='white')
    # 창 크기 및 위치 설정
    w = 600
    h = 470
    sw = window.winfo_screenwidth()
    sh = window.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2 - 50
    window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    window.resizable(width=False, height=False)
    photo = PhotoImage(file="img/kHouse.png")
    eh = Label(window, image=photo)
    eh.pack()
    Label(window, text="K하우스", bg='white', font=fnt).pack()
    ubtn = Button(window, text="정보 더보기", bg="white",
                  command=Kurl, font=fnt, width=30)
    ubtn.pack()
    window.mainloop()


def Dorm():
    window = Toplevel(s)
    window.title("성균관대학교 인사캠 2인실 기숙사 종류")
    window.configure(bg='white')
    # 창 크기 및 위치 설정
    w = 417
    h = 35
    sw = window.winfo_screenwidth()
    sh = window.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2 - 50
    window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    window.resizable(width=False, height=False)
    Btne = Button(window, text="E하우스", width=12, font=fnt,
                  bg='white', command=Edorm)
    Btne.pack(side=LEFT)
    Btng = Button(window, text="G하우스", width=12, font=fnt,
                  bg='white', command=Gdorm)
    Btng.pack(side=LEFT)
    Btnk = Button(window, text="K하우스", width=12, font=fnt,
                  bg='white', command=Kdorm)
    Btnk.pack(side=LEFT)
    window.mainloop()


# [프로그램 시작] 버튼
def start():
    # 창 크기 및 위치 설정
    s.configure(bg='white')
    w = 580
    h = 430
    sw = s.winfo_screenwidth()
    sh = s.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2 - 40
    s.geometry('%dx%d+%d+%d' % (w, h, x, y))
    s.resizable(width=False, height=False)
    # GUI 초기화
    allList = s.place_slaves()
    for i in allList:
        i.destroy()
    # 시작 화면 위젯 화면에 표시
    sLa1.grid(row=0, column=0, columnspan=4, pady=50, padx=50)
    sLa2.grid(row=1, column=0, columnspan=2, pady=20, padx=20)
    sEnt1.grid(row=1, column=2, columnspan=2, padx=30)
    sLa3.grid(row=2, column=0, columnspan=2, pady=20, padx=20)
    sRb1.grid(row=2, column=2)
    sRb2.grid(row=2, column=3)
    sLa4.grid(row=3, column=0, columnspan=2, pady=20, padx=20)
    sEnt2.grid(row=3, column=2, columnspan=2, padx=30)
    sBtn1.grid(row=4, column=0, columnspan=4, pady=20, padx=20)


# [사용자 정보 저장] 버튼
def save():
    global user_info
    uName = sEnt1.get()  # 시작화면 이름값
    uSex = ans.get()  # 시작화면 성별값
    uStdid = sEnt2.get()  # 시작화면 학번값
    if uName != "" and uSex != 0 and uStdid != "":  # 모두 입력이 됐을때만 리스트에 추가
        user_info.append(uName)
        user_info.append(uSex)
        user_info.append(uStdid)
        sBtn1.destroy()  # 버튼 클릭시 버튼 사라짐과 동시에 실행 버튼 생성
        sBtn2.grid(row=4, column=0, columnspan=4,
                   padx=20, pady=20)  # 설문 시작 버튼 생성


# [설문 시작] 버튼 & [다음 문제] 버튼
def nextWdw():
    s.configure(bg='white')
    global cnt
    global a
    # 매끄러운 프로그램 사용을 위한 장치
    if a == 1:
        w = 590
        h = 360
        sw = s.winfo_screenwidth()
        sh = s.winfo_screenheight()
        x = (sw-w)/2
        y = (sh-h)/2 - 40
        s.geometry('%dx%d+%d+%d' % (w, h, x, y))
        a += 1
        s.resizable(width=False, height=False)
    # GUI 초기화
    allList = s.grid_slaves()
    for i in allList:
        i.destroy()
        
    # 질문창
    sLaQ = Label(s, text=str(cnt+1)+". " +
                 df_qst[cnt+1][0], font=(fnt, 17), bg='white')  # 질문 출력
    sLaQ.grid(row=0, column=0, sticky=W)  # 질문 위치
    sLaUQ = Label(s, text="", font=10, bg='white')  # 질문과 보기 사이의 공간
    sLaUQ.grid(row=1, column=0, sticky=W)
    # 마지막 질문일 때는 다음 질문이 아닌 설문 종료 버튼 배치
    if cnt < 10:
        qBtn1 = Button(s, text="다음 질문", command=nextWdw,
                       width=15, font=fnt, background="white")
    elif cnt == 10:
        qBtn1 = Button(s, text="설문 종료", width=15, command=endWdw,
                       font=fnt, background="white")
        
    sRbQ = []  # 각 문항의 보기들을 담을 리스트
    sRbQ1 = Radiobutton(
        s, text=df_ans[cnt+1][0], variable=ans, value=1, font=fnt, background="white")
    sRbQ.append(sRbQ1)
    sRbQ2 = Radiobutton(
        s, text=df_ans[cnt+1][1], variable=ans, value=2, font=fnt, background="white")
    sRbQ.append(sRbQ2)
    sRbQ3 = Radiobutton(
        s, text=df_ans[cnt+1][2], variable=ans, value=3, font=fnt, background="white")
    sRbQ.append(sRbQ3)
    sRbQ4 = Radiobutton(
        s, text=df_ans[cnt+1][3], variable=ans, value=4, font=fnt, background="white")
    sRbQ.append(sRbQ4)
    sRbQ5 = Radiobutton(
        s, text=df_ans[cnt+1][4], variable=ans, value=5, font=fnt, background="white")
    sRbQ.append(sRbQ5)
    rbCnt = 1  # 문항당 null값이 아닌 보기의 개수 카운트
    
    for i in range(len(sRbQ)):
        if df_ans[cnt+1][i] != "null":
            # null값이 아닌 경우에만 GUI에 보이게 함.
            sRbQ[i].grid(row=i+2, column=0, sticky=W)
            rbCnt += 1
        for i in range(rbCnt, 7):
            qLa1 = Label(s, text="", font=fnt,
                         bg='white')  # 보기랑 다음 질문 버튼 사이 빈공간
            qLa1.grid(row=i+1, column=0, sticky=W)
        qBtn1.grid(row=8, column=0, sticky=W)
        
    # 진행률 게이지 바
    qLa2 = Label(s, text="", font=fnt, bg='white')  # 다음 질문 버튼과 진행률 바 사이 빈공간
    qLa2.grid(row=9, column=0, sticky=W)
    qLa3 = Label(s, text="<진행률> ", font=fnt, bg='white')
    qLa3.grid(row=10, column=0, sticky=W)
    pVar = DoubleVar()
    proBar = ttk.Progressbar(s, maximum=len(
        df_qst.columns), length=550, variable=pVar)
    pVar.set(cnt+1)
    proBar.grid(row=11, column=0, sticky=W)
    
    # 답변 리스트에 저장
    if(cnt > 0):
        global user_info
        qna = ans.get()
        user_info.append(qna)
    cnt += 1  # 다음 문제 출력으로 넘어가기 위함


# [설문 종료] 버튼
def endWdw():
    # 창 크기 및 위치 설정
    global s
    s.configure(bg='white')
    w = 527
    h = 280
    sw = s.winfo_screenwidth()
    sh = s.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2
    s.geometry('%dx%d+%d+%d' % (w, h, x, y))
    s.resizable(width=False, height=False)
    # 11번 (마지막 질문) 답변 리스트에 저장
    global user_info
    qna = ans.get()
    user_info.append(qna)
    # GUI 초기화
    allList = s.grid_slaves()
    for i in allList:
        i.destroy()
    # 결과 - 표본 데이터와의 각각의 유사도 점수 측정
    score = []  # 표본 데이터들과 사용자 데이터를 비교한 점수 각각을 저장할 리스트
    for i in range(1, len(df_setD.columns)):
        set_score = 100  # 초기 점수 : 100점
        # 성별이 같을 때만 판별할 것이므로 성별이 다를 경우 1000점 감점으로 선발의 가능성을 아예 배제함.
        if df_setD[i][1] != user_info[1]:
            set_score -= 1000
        # 1번 비교
        if df_setD[i][3]-user_info[3] == 1 or -1:
            set_score -= 5
        elif df_setD[i][3]-user_info[3] == 2 or -2:
            set_score -= 10
        elif df_setD[i][3]-user_info[3] == 3 or -3:
            set_score -= 45
        elif df_setD[i][3]-user_info[3] == 4 or -4:
            set_score -= 80
        # 2번 비교
        if df_setD[i][4]-user_info[4] == 1 or -1:
            set_score -= 5
        elif df_setD[i][4]-user_info[4] == 2 or -2:
            set_score -= 10
        elif df_setD[i][4]-user_info[4] == 3 or -3:
            set_score -= 45
        elif df_setD[i][4]-user_info[4] == 4 or -4:
            set_score -= 80
        # 3번 비교
        if df_setD[i][5] != user_info[5]:
            set_score -= 100
        # 4번 비교
        if df_setD[i][6] != user_info[6]:
            set_score -= 100
        # 5번 비교
        if df_setD[i][7] != user_info[7]:
            set_score -= 30
        # 6번 비교
        if df_setD[i][8] != user_info[8]:
            set_score -= 20
        # 7번 비교
        if df_setD[i][9] != user_info[9]:
            set_score -= 10
        # 8번 비교
        if df_setD[i][10] != user_info[10]:
            set_score -= 10
        # 9번 비교
        if df_setD[i][11] != user_info[11]:
            set_score -= 10
        # 10번 비교
        if df_setD[i][12] == 1 and user_info[12] == 2:
            set_score -= 5
        elif df_setD[i][12] == 2 and user_info[12] == 1:
            set_score -= 5
        # 11번 비교
        if df_setD[i][13] != user_info[13]:
            set_score -= 5
        score.append(set_score)  # 리스트에 최종점수 추가
    global max_num
    max_num = score.index(max(score))
    # 최종 결과 출력 코드
    eLa1 = Label(s, bg="white", font=(fnt, 17),
                 text="당신의 추천 돔메이트는 %s 입니다" % (df_setD[max_num+1][0]), width=40)
    eLa4 = Label(s, bg='white', text="")
    eLa2 = Label(s,  bg="white", font=fnt, text="이름 : %s" %
                 (df_setD[max_num+1][0]), width=40)
    eLa3 = Label(s,  bg="white", font=fnt, text="학번 : %s" %
                 (df_setD[max_num+1][2]), width=40)
    eLa5 = Label(s, bg='white', text="")
    eBtn1 = Button(s,  bg="white", font=fnt,
                   text="나의 답변 보기", command=myShow)
    eBtn2 = Button(s,  bg="white", font=fnt,
                   text="돔메의 답변 보기", command=dmShow)
    eLa6 = Label(s, bg='white', text="")
    eBtn3 = Button(s, bg="white", font=fnt,
                   text="설문정보 데이터에 저장", command=addData, width=40)
    eLa7 = Label(s, bg='white', text="")
    # 위젯 위치 설정
    eLa1.grid(row=0, column=0, columnspan=2)
    eLa4.grid(row=1, column=0, columnspan=2)
    eLa2.grid(row=2, column=0, columnspan=2)
    eLa3.grid(row=3, column=0, columnspan=2)
    eLa5.grid(row=4, column=0, columnspan=2)
    eLa6.grid(row=6, column=0, columnspan=2)
    eLa7.grid(row=8, column=0, columnspan=2)

    eBtn1.grid(row=5, column=0, columnspan=1)
    eBtn2.grid(row=5, column=1, columnspan=1)
    eBtn3.grid(row=7, column=0, columnspan=2)


# [나의 답변 보기] 버튼
def myShow():
    ms = Toplevel(s)
    ms.title("나의 답변")
    ms.configure(bg='white')
    # 창 크기 및 위치 설정
    w = 1050
    h = 630
    sw = ms.winfo_screenwidth()
    sh = ms.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2
    ms.geometry('%dx%d+%d+%d' % (w, h, x, y))
    ms.resizable(width=False, height=False)
    # 나의 답변 - 질문 : 답변 순으로 출력
    for i in range(len(df_qst.columns)):  # 질문 : 답변 *len(df_qst.columns)=len(df_ans.columns)
        msLa1 = Label(ms, bg="white", font=fnt, text=str(
            i+1)+". "+df_qst[i+1][0]+"  :  "+df_ans[i+1][user_info[i+3]-1])
        msLa1.grid(row=2*i, column=0, sticky=W)
    for i in range(len(df_ans.columns)):  # 문제 보기마다 칸 띄움
        msLa2 = Label(ms, text="", bg="white", font=fnt)
        msLa2.grid(row=2*i+1, column=0, sticky=W)
    msBtn = Button(ms, text="창 닫기", command=ms.destroy,
                   background='white', font=fnt, width=40)
    msBtn.grid(row=22, column=0)
    ms.mainloop()


# [돔메 답변 보기] 버튼
def dmShow():
    ds = Toplevel(s)
    ds.title("돔메의 답변")
    ds.configure(bg='white')
    # 창 크기 및 위치 설정
    w = 1050
    h = 630
    sw = ds.winfo_screenwidth()
    sh = ds.winfo_screenheight()
    x = (sw-w)/2
    y = (sh-h)/2
    ds.geometry('%dx%d+%d+%d' % (w, h, x, y))
    ds.resizable(width=False, height=False)
    # 매칭된 돔메의 답변 - 질문 : 답변 순으로 출력
    for i in range(len(df_qst.columns)):  # 질문 : 답변 *len(df_qst.columns)=len(df_ans.columns)
        dsLa1 = Label(ds, bg="white", font=fnt, text=str(
            i+1)+". "+df_qst[i+1][0]+"  :  "+df_ans[i+1][df_setD[max_num+1][i+3]-1])
        dsLa1.grid(row=2*i, column=0, sticky=W)
    for i in range(len(df_ans.columns)):  # 문제 보기마다 칸 띄움
        dsLa2 = Label(ds, text=" ", bg="white", font=fnt)
        dsLa2.grid(row=2*i+1, column=0, sticky=W)
    dsBtn = Button(ds, text="창 닫기", command=ds.destroy,
                   background='white', font=fnt, width=40)
    dsBtn.grid(row=22, column=0)
    ds.mainloop()


# [설문 정보 데이터에 저장] 버튼
def addData():
    global user_info
    # 사용자 정보 데이터 프레임에 추가
    series_user = pd.Series(user_info)  # 유저 정보 리스트로 우선 시리즈 생성
    # 시리즈를 표본 데이터프레임에 추가 : 데이터 축적 가능
    df_setD[len(df_setD.columns)] = series_user
    df_setD.to_excel("excel/IF_Team16_setData.xlsx",
                     sheet_name="setData", index=False)  # 엑셀 파일에 데이터프레임 덮어쓰기
    eLa4 = Label(s, bg="white", font=fnt,
                 text="사용자의 설문 정보가 데이터에 저장되었습니다.", width=40)
    eLa4.grid(row=7, column=0, columnspan=2)
    eBtn4 = Button(s, bg="red", fg="white", font=(fnt, 18),
                   text="프로그램 종료", width=13, command=s.destroy)
    eBtn4.grid(row=9, column=0, columnspan=2)  # 버튼 클릭 후 [프로그램 종료] 버튼 생성


# 시작 화면
startPhoto = PhotoImage(file="img/Start.png")
sPh1 = Label(s, image=startPhoto)
sPh1.place(x=-2, y=-2)
sBtn3 = Button(s, text="프로그램 시작", command=start, font=(
    fnt, 15), width=20, bg='white')
sBtn4 = Button(s, text="기숙사 정보 보기", font=(fnt, 10),
               command=Dorm, width=20, bg='white')
sBtn3.place(x=135, y=180)
sBtn4.place(x=175, y=145)

# 사용자 정보 입력 화면 위젯
sLa1 = Label(s, text="사용자 정보를 입력하세요", width=30, font=fnt, bg='white')
sLa2 = Label(s, text="이름", width=10, font=fnt, bg='white')
sLa3 = Label(s, text="성별", width=10, font=fnt, bg='white')
sLa4 = Label(s, text="학번", width=10, font=fnt, bg='white')
sEnt1 = Entry(s, width=30, font=fnt, bg='white')  # 이름
ans = IntVar()
sRb1 = Radiobutton(s, text="남자", variable=ans,
                   value=1, font=fnt, bg='white')
sRb2 = Radiobutton(s, text="여자", variable=ans,
                   value=2, font=fnt, bg='white')
sEnt2 = Entry(s, width=30, font=fnt, bg='white')  # 학번
sBtn1 = Button(s, text="사용자 정보 저장", command=save,
               width=30, font=fnt, bg='white')  # 사용자 정보 저장 버튼
sBtn2 = Button(s, text="설문 시작", command=nextWdw,
               width=30, font=fnt, bg='white')  # 질문창 생성 버튼

s.mainloop()
